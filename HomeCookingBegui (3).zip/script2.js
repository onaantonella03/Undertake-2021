//MOSTRAR BOTON DE CONTINUAR COMPRA
function mostrarBotonContinuar(){
  document.getElementById('btn-continuar').style.display = 'block';
}

// MOSTRAR CONTAINER DE FINALIZAR PEDIDO
function mostrarContainerPay(){
  document.getElementById('container-pay').style.display = 'block';
}

// MOSTRAR OPCIONES DE PAGO
//TRANSFERENCIA
function mostrarPayTF(){
  document.getElementById('payment_tf').style.display = 'block';
  document.getElementById('payment_mp').style.display = 'none';
  document.getElementById('payment_ef').style.display = 'none';
}
//MERCADO PAGO
function mostrarPayMP(){
  document.getElementById('payment_mp').style.display = 'block';
  document.getElementById('payment_tf').style.display = 'none';
  document.getElementById('payment_ef').style.display = 'none';
}
//EFECTIVO
function mostrarPayEF(){
  document.getElementById('payment_ef').style.display = 'block';
  document.getElementById('payment_tf').style.display = 'none';
  document.getElementById('payment_mp').style.display = 'none';
}
