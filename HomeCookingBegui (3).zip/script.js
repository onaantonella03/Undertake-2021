//PRODUCTOS

// Guardo los ID para poder manipuLarlos
const cards = document.getElementById("cards")
const items = document.getElementById("items")
const footer = document.getElementById("footer")
const templateCard = document.getElementById("template-card").content
const templateFooter = document.getElementById("template-footer").content
const templateCarrito = document.getElementById("template-carrito").content
const fragment = document.createDocumentFragment()

//Objeto carrito = Coleccion de objetos
let carrito = {}

//////////////////////////////////////////////////////////

//Cargua la página luego de leerse todo el html
document.addEventListener("DOMContentLoaded", () => {
  //Llamamos a la lectura de la API
  fetchData()

  //Guardo en local storage
  if (localStorage.getItem('carrito')) {
    carrito = JSON.parse(localStorage.getItem('carrito'))
    pintarCarrito()
  }
})

//Que las cards.addEventListener detecten el click y ejecutar una funcion
cards.addEventListener("click", e => {
  addCarrito(e)
})

//Click para usar botones
items.addEventListener("click", e => {
  btnAumentarDisminuir(e)
})


//Lectura de API
const fetchData = async () => {
  try {
    //Away espera que se lea la API y despues se sigue
    const res = await fetch("https://opensheet.vercel.app/16CWwaROk4ksRT7frDZOxl6fbF3slps9-GnwKvO_npms/Hoja+1")

    //Guarda cada dato
    const data = await res.json()
    pintarCards(data)

  } catch (error) {
    //Por si hay algun error
    console.log(error)
  }
}

//Pinta Productos en tarjeta
const pintarCards = data => {
  //console.log(data)
  data.forEach(producto => {

    //Nombre del producto
    templateCard.querySelector("h5").textContent = producto.nombre

    //Precio del producto
    templateCard.querySelector("p span").textContent = producto.precio

    //Imagen del producto
    templateCard.querySelector("img").setAttribute("src", producto.imagen)

    //ID del producto
    templateCard.querySelector(".btn-dark").dataset.id = producto.id

    //Crea clon de templateCard
    const clone = templateCard.cloneNode(true)
    //Pasa el clon
    fragment.appendChild(clone)
  })

  cards.appendChild(fragment)
}

//////////////////////////////////////////////////////////

//Para agregar a carrito
const addCarrito = e => {
  //Si hay click en boton btn-dark
  if (e.target.classList.contains("btn-dark")) {
    //Pinta objeto seleccionado
    setCarrito(e.target.parentElement)

    //Alerta carrito
    const alert = document.querySelector(".alert")
    setTimeout( function(){
      alert.classList.add("alerta-add")
    }, 3000)
    alert.classList.remove("alerta-add")
  }

  //Para detener otro evento generado
  e.stopPropagation()
}

//Boton "Agregar" lleva los datos del producto a setcarrito
//Captura los elementos
const setCarrito = objeto => {
  //Carrito = + objetos
  //Producto = 1 objeto
  const producto = {
    //Ahora este objeto toma el id del producto
    id: objeto.querySelector(".btn-dark").dataset.id,
    //este objeto toma el Nombre del producto
    nombre: objeto.querySelector("h5").textContent,
    //este objeto toma el precio del producto
    precio: objeto.querySelector("p span").textContent,
    //Cantidad de inicio 1
    cantidad: 1
  }

  //Si el producto existe en el carrito
  if (carrito.hasOwnProperty(producto.id)) {
    //Se agrega una cantidad del mismo
    producto.cantidad = carrito[producto.id].cantidad + 1
  }
  //Busca la informacion y hace copia del producto
  carrito[producto.id] = { ...producto }

  pintarCarrito()
}

//Agrega productos al carrito
const pintarCarrito = () => {
  //Empieza vacio
    items.innerHTML = ''
    //Pone los productos en el carrito
    Object.values(carrito).forEach(producto => {
        templateCarrito.querySelector('th').textContent = producto.id
        templateCarrito.querySelectorAll('td')[0].textContent = producto.nombre
        templateCarrito.querySelectorAll('td')[1].textContent = producto.cantidad
        //Cantidades
        templateCarrito.querySelector('span').textContent = producto.precio * producto.cantidad
        
        //botones
        templateCarrito.querySelector('.btn-info').dataset.id = producto.id
        templateCarrito.querySelector('.btn-danger').dataset.id = producto.id

        const clone = templateCarrito.cloneNode(true)
        fragment.appendChild(clone)
    })
    items.appendChild(fragment)
    pintarFooter()

    //guardando en local storage la colexion de obejto a string plano ahi y cuando la llamo vuelve
    localStorage.getItem('carrito', JSON.stringify(carrito))
}

const pintarFooter = () => {
  //Comineza vacio
  footer.innerHTML = ""
  if (Object.keys(carrito).length === 0) {
    footer.innerHTML = `
        <th scope="row" colspan="5"> Carrito vacio - comience a comprar!</th>
        `
    return
  }

  // sumar cantidad y sumar totales
  const nCantidad = Object.values(carrito).reduce((acc, { cantidad }) => acc + cantidad, 0)

  const nPrecio = Object.values(carrito).reduce((acc, { cantidad, precio }) => acc + cantidad * precio, 0)
  //console.log(nPrecio)

  templateFooter.querySelectorAll("td")[0].textContent = nCantidad
  templateFooter.querySelector("span").textContent = nPrecio

  const clone = templateFooter.cloneNode(true)
  fragment.appendChild(clone)

  footer.appendChild(fragment)

  const btnVaciar = document.querySelector("#vaciar-carrito")
  btnVaciar.addEventListener("click", () => {
    carrito = {}
    pintarCarrito()
  })
}

//BONTONES + y - de CANTIDAD
const btnAumentarDisminuir = e => {
  // AUMENTAR CANTIDAD
  if (e.target.classList.contains("btn-info")) {
    const producto = carrito[e.target.dataset.id]
    producto.cantidad++
    carrito[e.target.dataset.id] = { ...producto }
    pintarCarrito()
  }
  //DISMINUIR CANTIDAD
  if (e.target.classList.contains("btn-danger")) {
    const producto = carrito[e.target.dataset.id]
    producto.cantidad--
    if (producto.cantidad === 0) {
      delete carrito[e.target.dataset.id]
    } else {
      carrito[e.target.dataset.id] = { ...producto }
    }
    pintarCarrito()
  }
  e.stopPropagation()
}

//////////////////////////////////////////////////////////

//ENVIAR WHATSAPP CON CARRITO
popupWhatsApp = () => {
  let sendBtn = document.getElementById("btn-fincompra");
  sendBtn.addEventListener("click", () => {
    
    let nombre = document.getElementById('firstName').value;
    let apellido = document.getElementById('lastName').value;
    let hola = ("Hola! Mi nombre es: ") + nombre + apellido;

    //let dir1 = document.getElementById('address').value;
    //let di2= document.getElementById('address2').value;
    //let direccion = ("Mi direccion es: ") + dir1 + dir2;

    //let texto = hola + direccion;

    let mmensaje = JSON.stringify(carrito);
    let mensajeCodificado = encodeURIComponent(mmensaje);

    window.open("https://wa.me/541132172344?text="+hola+mensajeCodificado, '_blank');
  });
}
popupWhatsApp();

//console.log(mensajeCodificado)
//let relmsg = mensajeCodificado.replace(/ /g,"%20");